from django.contrib import admin
from django.urls import path
from app1 import views

urlpatterns=[
    path('',views.login),
    path('create_account',views.create_account),
    path('login',views.login),
    path('password',views.password),
    path('inbox',views.inbox),
    path('compose',views.compose),
    path('sent',views.sent),
    path('starred',views.starred),
    path('trash',views.trash), 
    path('inbox_view',views.inbox_view),   
    path('starred_view',views.starred_view),  
    path('sent_view',views.sent_view),  
    path('trash_view',views.trash_view),  
]
from django.http import HttpResponseRedirect
from django.shortcuts import render
from app1 import dbconnection
from datetime import date,datetime,timedelta
# Create your views here.

def create_account(request):
    if request.POST.get('create'):
        f=request.POST.get('fname')
        l=request.POST.get('lname')
        u=request.POST.get('username')
        u_name=u+'@gmail.com'
        p=request.POST.get('password')
        sql2="select * from login where username='"+u_name+"'"
        data2=dbconnection.selectall(sql2)
        if data2:
            msg="That username is taken.Try another."
            return render(request,"create_account.html",{'msg':msg})
        else:
            sql1="insert into login(f_name,l_name,username,password,status)values('"+f+"','"+l+"','"+u_name+"','"+p+"',1)"
            dbconnection.insert(sql1)
            return render(request,"create_account.html",{})  
    return render(request,"create_account.html",{})  

def login(request):
    if request.POST.get('next'):
        u=request.POST.get('username')
        sql="select * from login where username='"+u+"'"
        data1=dbconnection.selectone(sql)
        if data1 == None:
            msg="!couldn't find your google account"
            return render(request,"login.html",{'msg':msg})
        if data1[3]== u:    
            request.session['username']=u
            return HttpResponseRedirect('password')
        else:
            return HttpResponseRedirect('login')
    return render(request,"login.html",{})

def password(request):
    u=request.session['username']
    sql="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql)
   
    if request.POST.get('next'):
        p=request.POST.get('password') 
        sql2="select * from login where username='"+u+"'and password='"+p+"'"
        data2=dbconnection.selectone(sql2)

        if data2==None:
            msg="wrong password.Try again or click Forgot Password to reset it."
            return render(request,"password.html",{'data1':data1,'msg':msg})
        elif data2[3] == u:
            request.session['username']=u
            request.session['password']=p
            return HttpResponseRedirect('inbox') 
        else:
            msg="user does not exist"
            return render(request,"password.html",{'msg':msg})    
    return render(request,"password.html",{'data1':data1})    

def inbox(request):
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)
    # msg_id=request.GET['msg_id']

    sql2="select * from inbox where recepient='"+u+"' and delete_status=0  order by msg_id DESC"       #recepient=username)
    data2=dbconnection.selectall(sql2)
    # print(data2)

    #star
    if request.POST.get('n_star'):
        for i in data2:    
            if i[1]==u:    #sender=username
                msg_id=request.POST.get('msg_id')
                # print(msg_id)
                sql3="update inbox set sender_starred=1 , starred=1 where msg_id='"+msg_id+"'"
                dbconnection.update(sql3)
            else:
                msg_id=request.POST.get('msg_id')
                sql4="update inbox set starred=1 where msg_id='"+msg_id+"'"   
                dbconnection.update(sql4) 
        return HttpResponseRedirect('inbox')
    if request.POST.get('star'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql5="update inbox set sender_starred=0 , starred=0 where msg_id='"+msg_id+"'"
                dbconnection.update(sql5)
            else:
                msg_id=request.POST.get('msg_id')
                sql6="update inbox set starred=0 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql6)  
            return HttpResponseRedirect('inbox')
    # msg read & unread
        
    if request.POST.get('unread'):
        u_id =  request.POST.get('msg_id')                        
        for i in data2:
            if int(u_id)==i[0]:
             if i[1]==u:  
                #msg_id=request.POST.get('msg_id') 
                sql7="update inbox set sender_status=1 , status=1 where msg_id='"+u_id+"'"
                dbconnection.update(sql7)
            else:
                #msg_id=request.POST.get('msg_id')
                sql8="update inbox set status=1 where msg_id='"+u_id+"'"  
                dbconnection.update(sql8)  
        return HttpResponseRedirect('inbox')   

    if request.POST.get('read'):   
        u_id =  request.POST.get('msg_id')            
        for i in data2:
            if int(u_id)==i[0]:
                if i[1]==u:  
                    #msg_id=request.POST.get('msg_id') 
                    sql9="update inbox set sender_status=0 , status=0 where msg_id='"+u_id+"'"
                    dbconnection.update(sql9)
            else:
                    #msg_id=request.POST.get('msg_id')
                    sql10="update inbox set status=0 where msg_id='"+u_id+"'"  
                    dbconnection.update(sql10)  
        return HttpResponseRedirect('inbox') 

    # delete icon
    if request.POST.get('delete'):  
        u_id =  request.POST.get('msg_id')         
        for i in data2:
            if int(u_id)==i[0]:
                if i[1]==i[2]:  
                    # msg_id=request.POST.get('msg_id') 
                    sql7="update inbox set sender_delete_status=1 , delete_status=1 where msg_id='"+u_id+"'"
                    dbconnection.update(sql7)
                else:
                    #msg_id=request.POST.get('msg_id')
                    sql8="update inbox set delete_status=1 where msg_id='"+u_id+"'"  
                    dbconnection.update(sql8)  
        return HttpResponseRedirect('inbox')   
               

    return render(request,"inbox.html",{'data1':data1,'data2':data2})  

def inbox_view(request):
    msg_id=request.GET['msg_id']
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    sql2="select * from inbox where recepient='"+u+"' and delete_status=0 and msg_id='"+msg_id+"'  order by msg_id DESC"       #recepient=username)
    data2=dbconnection.selectone(sql2)

    # msg read
    if (data2[1]==u) and (data2[9] == data2[12] == 0):    #sender=username
            # print(msg_id)
            sql7="update inbox set sender_status=1 , status=1 where msg_id='"+msg_id+"'"
            dbconnection.update(sql7)
            return HttpResponseRedirect('inbox_view?msg_id='+msg_id)   

    if (data2[9] == 0):
            sql8="update inbox set status=1 where msg_id='"+msg_id+"'"   
            dbconnection.update(sql8) 
            return HttpResponseRedirect('inbox_view?msg_id='+msg_id) 
   
    #reply
    if request.POST.get('reply'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        c=request.POST.get('content')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+c+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox')
    #forward
    if request.POST.get('forward'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        fc=request.POST.get('fc')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+fc+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox') 

    return render(request,"inbox_view.html",{'data1':data1,'data2':data2})


def compose(request):
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    if request.POST.get('send'):
        r=request.POST.get('recipient')
        s=request.POST.get('subject')
        m=request.POST.get('message')
        m_date=date.today()   #order_date
        s_today=str(m_date)
        sql2="insert into inbox(sender,recepient,subject,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+s+"','"+m+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+u+"')"
        dbconnection.insert(sql2)
        return HttpResponseRedirect('compose') 
    return render(request,"compose.html",{'data1':data1})

def sent(request):
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    sql2="select * from inbox where sender='"+u+"'and sender_delete_status=0 order by msg_id DESC"     #sender=username)
    data2=dbconnection.selectall(sql2)

     #star
    if request.POST.get('n_star'):
        for i in data2:    
            if i[1]==u:    #sender=username
                msg_id=request.POST.get('msg_id')
                # print(msg_id)
                sql3="update inbox set sender_starred=1 , starred=1 where msg_id='"+msg_id+"'"
                dbconnection.update(sql3)
            else:
                msg_id=request.POST.get('msg_id')
                sql4="update inbox set starred=1 where msg_id='"+msg_id+"'"   
                dbconnection.update(sql4) 
        return HttpResponseRedirect('sent')
    if request.POST.get('star'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql5="update inbox set sender_starred=0 , starred=0 where msg_id='"+msg_id+"'"
                dbconnection.update(sql5)
            else:
                msg_id=request.POST.get('msg_id')
                sql6="update inbox set starred=0 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql6)  
            return HttpResponseRedirect('sent')
    # msg read & unread
        
    if request.POST.get('unread'): 
        u_id =  request.POST.get('msg_id')              
        for i in data2:
            if int(u_id)==i[0]:
                if i[1]==u:  
                    msg_id=request.POST.get('msg_id') 
                    sql7="update inbox set sender_status=1 , status=1 where msg_id='"+msg_id+"'"
                    dbconnection.update(sql7)
                else:
                    msg_id=request.POST.get('msg_id')
                    sql8="update inbox set status=1 where msg_id='"+msg_id+"'"  
                    dbconnection.update(sql8)  
        return HttpResponseRedirect('sent')   

    if request.POST.get('read'):
        u_id =  request.POST.get('msg_id')                     
        for i in data2:
            if int(u_id)==i[0]:
                if i[1]==u:  
                    msg_id=request.POST.get('msg_id') 
                    sql9="update inbox set sender_status=0 , status=0 where msg_id='"+msg_id+"'"
                    dbconnection.update(sql9)
                else:
                    msg_id=request.POST.get('msg_id')
                    sql10="update inbox set status=0 where msg_id='"+msg_id+"'"  
                    dbconnection.update(sql10)  
        return HttpResponseRedirect('sent') 

    # delete icon
    if request.POST.get('delete'):  
        u_id =  request.POST.get('msg_id')         
        for i in data2:
            if int(u_id)==i[0]:
                if i[1]==i[2]:  
                    # msg_id=request.POST.get('msg_id') 
                    sql7="update inbox set sender_delete_status=1 , delete_status=1 where msg_id='"+u_id+"'"
                    dbconnection.update(sql7)
                else:
                    #msg_id=request.POST.get('msg_id')
                    sql8="update inbox set sender_delete_status=1 where msg_id='"+u_id+"'"  
                    dbconnection.update(sql8)  
        return HttpResponseRedirect('sent')  

    return render(request,"sent.html",{'data1':data1,'data2':data2})   

def sent_view(request):
    msg_id=request.GET['msg_id']
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    sql2="select * from inbox where (recepient='"+u+"'and starred=1 and delete_status=0) OR (sender='"+u+"' AND sender_starred=1 AND sender_delete_status=0) order by msg_id DESC"     #sender=username)
    data2=dbconnection.selectone(sql2)
   
    #reply
    if request.POST.get('reply'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        c=request.POST.get('content')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+c+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox')
    #forward
    if request.POST.get('forward'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        fc=request.POST.get('fc')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+fc+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox') 

    # msg read
    if (data2[1]==u) and (data2[9] == data2[12] == 0):    #sender=username
            # print(msg_id)
            sql7="update inbox set sender_status=1 , status=1 where msg_id='"+msg_id+"'"
            dbconnection.update(sql7)
            return HttpResponseRedirect('sent_view?msg_id='+msg_id)   

    if (data2[9] == 0):
            sql8="update inbox set status=1 where msg_id='"+msg_id+"'"   
            dbconnection.update(sql8) 
            return HttpResponseRedirect('sent_view?msg_id='+msg_id)   
    return render(request,"sent_view.html",{'data1':data1,'data2':data2})       

def starred(request):
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    sql2="select * from inbox where (recepient='"+u+"'and starred=1 and delete_status=0) OR (sender='"+u+"' AND sender_starred=1 AND sender_delete_status=0) order by msg_id DESC"     #sender=username)
    data2=dbconnection.selectall(sql2)

#star
    if request.POST.get('n_star'):
        for i in data2:    
            if i[1]==u:    #sender=username
                msg_id=request.POST.get('msg_id')
                # print(msg_id)
                sql3="update inbox set sender_starred=1 , starred=1 where msg_id='"+msg_id+"'"
                dbconnection.update(sql3)
            else:
                msg_id=request.POST.get('msg_id')
                sql4="update inbox set starred=1 where msg_id='"+msg_id+"'"   
                dbconnection.update(sql4) 
        return HttpResponseRedirect('starred')
    if request.POST.get('star'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql5="update inbox set sender_starred=0 , starred=0 where msg_id='"+msg_id+"'"
                dbconnection.update(sql5)
            else:
                msg_id=request.POST.get('msg_id')
                sql6="update inbox set starred=0 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql6)  
            return HttpResponseRedirect('starred')
    # msg read & unread
        
    if request.POST.get('unread'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql7="update inbox set sender_status=1 , status=1 where msg_id='"+msg_id+"'"
                dbconnection.update(sql7)
            else:
                msg_id=request.POST.get('msg_id')
                sql8="update inbox set status=1 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql8)  
        return HttpResponseRedirect('inbox')   

    if request.POST.get('read'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql9="update inbox set sender_status=0 , status=0 where msg_id='"+msg_id+"'"
                dbconnection.update(sql9)
            else:
                msg_id=request.POST.get('msg_id')
                sql10="update inbox set status=0 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql10)  
        return HttpResponseRedirect('inbox') 

    # delete icon
    if request.POST.get('delete'):  
        u_id =  request.POST.get('msg_id')         
        for i in data2:
            if int(u_id)==i[0]:
                if i[1]==i[2]:  
                    # msg_id=request.POST.get('msg_id') 
                    sql7="update inbox set sender_delete_status=1 , delete_status=1 where msg_id='"+u_id+"'"
                    dbconnection.update(sql7)
                else:
                    #msg_id=request.POST.get('msg_id')
                    sql8="update inbox set sender_delete_status=1 where msg_id='"+u_id+"'"  
                    dbconnection.update(sql8)  
        return HttpResponseRedirect('starred')  

    return render(request,"starred.html",{'data1':data1,'data2':data2})  

def starred_view(request):
    msg_id=request.GET['msg_id']
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    sql2="select * from inbox where (recepient='"+u+"'and starred=1 and delete_status=0) OR (sender='"+u+"' AND sender_starred=1 AND sender_delete_status=0) order by msg_id DESC"     #sender=username)
    data2=dbconnection.selectone(sql2)
   
    #reply
    if request.POST.get('reply'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        c=request.POST.get('content')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+c+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox')
    #forward
    if request.POST.get('forward'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        fc=request.POST.get('fc')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+fc+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox') 

    # msg read
    if (data2[1]==u) and (data2[11] == data2[14] == 0):    #sender=username
            # print(msg_id)
            sql7="update inbox set sender_starred=1 , starred=1 where msg_id='"+msg_id+"'"
            dbconnection.update(sql7)
            return HttpResponseRedirect('starred_view?msg_id='+msg_id)   

    if (data2[11] == 0):
            sql8="update inbox set starred=1 where msg_id='"+msg_id+"'"   
            dbconnection.update(sql8) 
            return HttpResponseRedirect('starred_view?msg_id='+msg_id)   
    return render(request,"starred_view.html",{'data1':data1,'data2':data2})      

def trash(request):
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    sql2="select * from inbox where (recepient='"+u+"'and delete_status=1) OR (sender='"+u+"' AND  sender_delete_status=1) order by msg_id DESC"     #sender=username)
    data2=dbconnection.selectall(sql2)

    #star
    if request.POST.get('n_star'):
        for i in data2:    
            if i[1]==u:    #sender=username
                msg_id=request.POST.get('msg_id')
                # print(msg_id)
                sql3="update inbox set sender_starred=1 , starred=1 where msg_id='"+msg_id+"'"
                dbconnection.update(sql3)
            else:
                msg_id=request.POST.get('msg_id')
                sql4="update inbox set starred=1 where msg_id='"+msg_id+"'"   
                dbconnection.update(sql4) 
        return HttpResponseRedirect('trash')
    if request.POST.get('star'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql5="update inbox set sender_starred=0 , starred=0 where msg_id='"+msg_id+"'"
                dbconnection.update(sql5)
            else:
                msg_id=request.POST.get('msg_id')
                sql6="update inbox set starred=0 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql6)  
            return HttpResponseRedirect('trash')

             # msg read & unread
        
    if request.POST.get('unread'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql7="update inbox set sender_status=1 , status=1 where msg_id='"+msg_id+"'"
                dbconnection.update(sql7)
            else:
                msg_id=request.POST.get('msg_id')
                sql8="update inbox set status=1 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql8)  
        return HttpResponseRedirect('trash')   

    if request.POST.get('read'):            
        for i in data2:
            if i[1]==u:  
                msg_id=request.POST.get('msg_id') 
                sql9="update inbox set sender_status=0 , status=0 where msg_id='"+msg_id+"'"
                dbconnection.update(sql9)
            else:
                msg_id=request.POST.get('msg_id')
                sql10="update inbox set status=0 where msg_id='"+msg_id+"'"  
                dbconnection.update(sql10)  
        return HttpResponseRedirect('trash') 

    if request.POST.get('delete'):
        msg_id=request.POST.get('msg_id')
        sql1="select sender,recepient,delete_status,sender_delete_status from inbox where msg_id='"+msg_id+"'"
        datad=dbconnection.selectone(sql1)
        if (datad[0]==datad[1]):
            sql="delete from inbox where msg_id='"+msg_id+"'"
            dbconnection.delete(sql)
            return HttpResponseRedirect('trash')
        if datad[0]==u:
            sql2="update inbox set sender_delete_status=2 where msg_id='"+msg_id+"'"
            dbconnection.update(sql2)
            return HttpResponseRedirect('trash')
        sql3="update inbox set delete_status =2 where msg_id='"+msg_id+"'"
        dbconnection.update(sql3)        
    return render(request,"trash.html",{'data1':data1,'data2':data2})

def trash_view(request):
    msg_id=request.GET['msg_id']
    u=request.session['username']
    sql1="select * from login where username='"+u+"'"
    data1=dbconnection.selectone(sql1)

    sql2="select * from inbox where (recepient='"+u+"'and delete_status=1) OR (sender='"+u+"' AND  sender_delete_status=1) order by msg_id DESC"     #sender=username)
    data2=dbconnection.selectone(sql2)
   
    #reply
    if request.POST.get('reply'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        c=request.POST.get('content')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+c+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox')
    #forward
    if request.POST.get('forward'):
        r=request.POST.get('recepient')
        # s=request.POST.get('subject')
        fc=request.POST.get('fc')
        msg_date=date.today()
        s_today=str(msg_date)
        sql3="insert into inbox(sender,recepient,message,message_date,status,f_name,l_name,username)values('"+data1[3]+"','"+r+"','"+fc+"','"+s_today+"',0,'"+data1[1]+"','"+data1[2]+"','"+data1[3]+"')"
        dbconnection.insert(sql3)
        return HttpResponseRedirect('inbox') 

     # msg read
    if (data2[1]==u) and (data2[9] == data2[12] == 0):    #sender=username
            # print(msg_id)
            sql7="update inbox set sender_status=1 , status=1 where msg_id='"+msg_id+"'"
            dbconnection.update(sql7)
            return HttpResponseRedirect('trash_view?msg_id='+msg_id)   

    if (data2[9] == 0):
            sql8="update inbox set status=1 where msg_id='"+msg_id+"'"   
            dbconnection.update(sql8) 
            return HttpResponseRedirect('trash_view?msg_id='+msg_id)   
    return render(request,"trash_view.html",{'data1':data1,'data2':data2})       
